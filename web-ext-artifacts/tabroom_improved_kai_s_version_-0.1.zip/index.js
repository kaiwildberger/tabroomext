// tabroom.com/register/index.mhtml is the school input page; /register/school/edit.mhtml needs it as well
// copy email to clipboard instead of mailto addr

console.log("extension init")

var features = {
    spaceSchoolFocus: true,
    copyMailtoLink: true
}

// currently this is two hits of the spacebar which is okay. i'd prefer it be a single one but what the hell.
// its doing that because i'm just focusing the bar and then hitting spacebar does it through firefox anyways. the dispatchevent doesn't even work.
window.addEventListener("keydown", key => {
    if(key.code === "Space") {
        let typeatr = document.activeElement.getAttribute("type")
        if (document.activeElement.tagName.toLowerCase() == "input" && (typeatr == "text" | typeatr == "search")) {
            console.log('active elemtn is text prompt')
            return;
        } else {
            if(window.location.toString().includes("/register/index.mhtml") | window.location.toString().includes("/register/school/edit.mhtml")) {    
                let click = new Event("keydown", {})
                let cb = document.querySelector(`span.select2-selection`)
                cb.focus()
                cb.dispatchEvent(click)
                key.preventDefault()
            } else {
                // console.log("wrong page")
                return;
            }
        }
    }
})

Array.from(document.querySelectorAll("a")).forEach(e => {
    if(e.href.includes("mailto:")) {
        e.addEventListener("click", event => { // bro uses mousedown everywhere. is Click bad or is it typical tabroom behavior
            navigator.clipboard.writeText(e.href.replace("mailto:", ""))
            console.log(e.href.replace("mailto:", ""))
            event.preventDefault()
        })
    }
})